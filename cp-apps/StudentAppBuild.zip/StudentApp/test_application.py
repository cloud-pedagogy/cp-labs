"Demo Student Directory application Test cases"
import json
import os
import subprocess
import urllib.request

from flask import Flask, render_template, render_template_string, url_for, redirect, flash, g
from flask_wtf import FlaskForm
from flask_wtf.file import FileField
from wtforms import StringField, HiddenField, validators
import boto3

import config
import util

def before_request():
    """
    PyTest tests are callables whose names start with "test"
    (by default)

    It looks for them in modules whose name starts with "test_" or ends with "_test"
    (by default)
    """
    pass


def home():
    """
    My name doesn't start with "test", so I won't get run.
    (by default ;-)
    """
    pass
