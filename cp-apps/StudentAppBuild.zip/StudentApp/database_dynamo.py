"Database layer - the dynamo version"
import uuid

import boto3

def list_students():
    "Select all the students from the database"
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('students')
        return table.scan()["Items"]
    except: # pylint: disable=bare-except
        return 0

def load_student(student_id):  # pylint: disable=R1710
    "Select one the student from the database"
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('students')
        response = table.get_item(
            Key={
                'id': student_id
            }
        )
        return response['Item']
    except: # pylint: disable=bare-except
        pass

def add_student(object_key, full_name, location, dept_title):
    "Add an student to the database"
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('students')
        item = {
            'id': str(uuid.uuid4()),
            'full_name': full_name,
            'dept_title': dept_title,
            'location': location
        }
        if object_key:
            item['object_key'] = object_key
        table.put_item(
            Item=item
        )
    except: # pylint: disable=bare-except
        pass


def update_student(student_id, object_key, full_name, location, dept_title):
    "Update an student to the database"
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('students')
        item = {
            'full_name': {'Value': full_name, 'Action': 'PUT'},
            'dept_title': {'Value': dept_title, 'Action': 'PUT'},
            'location': {'Value': location, 'Action': 'PUT'}
        }
        if object_key:
            item['object_key'] = {'Value': object_key, 'Action': 'PUT'}
        table.update_item(
            Key={
                'id': student_id
            },
            AttributeUpdates=item
        )
    except: # pylint: disable=bare-except
        pass

def delete_student(student_id):
    "Delete a student."
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('students')
        table.delete_item(
            Key={
                'id': student_id
            }
        )
    except: # pylint: disable=bare-except
        pass

