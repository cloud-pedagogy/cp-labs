Create Codecommit Repo = StudentApp
Create an S3 bucket = cp-out-bucket

Cloud Build Code - StudentAppBuild.zip
