"Database layer - next time use SQLAlchemy"
import mysql.connector
import config

def test_add_students():
    "Add students to the database"
    conn = get_database_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""INSERT INTO students (object_key, full_name, location, job_title)
     VALUES (%s, %s, %s, %s, %s);""", ("1", "Resh", "India", "Tech Trainer"))
    cursor.execute("""INSERT INTO students (object_key, full_name, location, job_title)
     VALUES (%s, %s, %s, %s, %s);""", ("2", "Kins", "USA", "Developer"))
    cursor.execute("""SELECT id, object_key, full_name, location, job_title
        FROM students
        ORDER BY full_name desc""")
    conn.commit()
    cursor.close()
    conn.close()

def test_list_students():
    "Select all the students from the database"
    conn = get_database_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""SELECT id, object_key, full_name, location, job_title
        FROM students
        ORDER BY full_name desc""")
    result = cursor.fetchall()
    # Define the expected results as a list of tuples.
    expected_results = [('1', 'Resh', 'India', 'Tech Trainer'),('2', 'Kins', 'USA', 'Developer')]
    # Assert that the results match the expected results.
    self.assertEqual(results, expected_results)
    cursor.close()
    conn.close()
    return result
def test_delete_students(students_id):
    "Delete student."
    conn = get_database_connection()
    cursor = conn.cursor()
    cursor.execute("""DELETE FROM students WHERE id = %(emp)s;""", {'emp': '1'})
    conn.commit()
    cursor.close()
    conn.close()
def test_get_database_connection():
    "Build a database connection"
    conn = mysql.connector.connect(user=config.DATABASE_USER, password=config.DATABASE_PASSWORD,
                                   host=config.DATABASE_HOST,
                                   database=config.DATABASE_DB_NAME,
                                   use_pure=True) # see https://bugs.mysql.com/90585
    return conn


