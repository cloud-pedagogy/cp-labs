"Database layer - the dynamo version"
import uuid

import boto3
def test_add_student():
    "Add an student to the database"
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('students')
        item = {
            'id': '1',
            'full_name': 'Resh',
            'dept_title': 'Trainer',
            'location': 'India'
        }
        table.put_item(
            Item=item
        )
    except: # pylint: disable=bare-except
        pass
def test_list_students():
    "Select all the students from the database"
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('students')
        return table.scan()["Items"]
    except: # pylint: disable=bare-except
        return 0
